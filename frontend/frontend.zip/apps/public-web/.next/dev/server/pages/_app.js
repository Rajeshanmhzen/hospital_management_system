var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__497e1d9d._.js")
R.m("[project]/apps/public-web/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_cd686fafa065e16de73e229f5879b04d/node_modules/next/app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/apps/public-web/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_cd686fafa065e16de73e229f5879b04d/node_modules/next/app.js [ssr] (ecmascript)").exports
