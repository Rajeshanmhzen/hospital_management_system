__turbopack_load_page_chunks__("/_app", [
  "static/chunks/bd32d_next_dist_compiled_98b96a4f._.js",
  "static/chunks/bd32d_next_dist_shared_lib_3b45c825._.js",
  "static/chunks/bd32d_next_dist_client_23ae2180._.js",
  "static/chunks/bd32d_next_dist_e4bbdf13._.js",
  "static/chunks/bd32d_next_app_3a0fc8be.js",
  "static/chunks/[next]_entry_page-loader_ts_b728049a._.js",
  "static/chunks/efe81_react-dom_ea2937d6._.js",
  "static/chunks/d39f3__pnpm_8d038593._.js",
  "static/chunks/[root-of-the-server]__c62f4c2f._.js",
  "static/chunks/apps_public-web_pages__app_2da965e7._.js",
  "static/chunks/turbopack-apps_public-web_pages__app_9a86ec5e._.js"
])
