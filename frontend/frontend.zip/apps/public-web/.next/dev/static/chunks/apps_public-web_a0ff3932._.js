(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c6ccd43b._.js",
  "static/chunks/bd32d_next_dist_compiled_react-dom_2da24e2e._.js",
  "static/chunks/bd32d_next_dist_compiled_react-server-dom-turbopack_1cb71352._.js",
  "static/chunks/bd32d_next_dist_compiled_next-devtools_index_6489bc6c.js",
  "static/chunks/bd32d_next_dist_compiled_e70a547c._.js",
  "static/chunks/bd32d_next_dist_client_c3057032._.js",
  "static/chunks/bd32d_next_dist_7e0e7273._.js",
  "static/chunks/86d5e_@swc_helpers_cjs_3a72ea9a._.js"
],
    source: "entry"
});
