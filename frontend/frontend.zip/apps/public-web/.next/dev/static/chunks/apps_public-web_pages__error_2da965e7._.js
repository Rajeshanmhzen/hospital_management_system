(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/bd32d_next_dist_compiled_98b96a4f._.js",
  "static/chunks/bd32d_next_dist_shared_lib_e2d92501._.js",
  "static/chunks/bd32d_next_dist_client_23ae2180._.js",
  "static/chunks/bd32d_next_dist_ed4a224a._.js",
  "static/chunks/bd32d_next_error_18aba50f.js",
  "static/chunks/[next]_entry_page-loader_ts_29328ee1._.js",
  "static/chunks/efe81_react-dom_ea2937d6._.js",
  "static/chunks/d39f3__pnpm_8d038593._.js",
  "static/chunks/[root-of-the-server]__493ff86b._.js"
],
    source: "entry"
});
