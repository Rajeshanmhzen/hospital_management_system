var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/d39f3__pnpm_a0aaa401._.js")
R.c("server/chunks/ssr/[externals]__e6a4d965._.js")
R.m("[project]/apps/public-web/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_cd686fafa065e16de73e229f5879b04d/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/apps/public-web/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_cd686fafa065e16de73e229f5879b04d/node_modules/next/document.js [ssr] (ecmascript)").exports
